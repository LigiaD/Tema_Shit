package com.tema1.main;

import com.tema1.goods.Goods;
import com.tema1.goods.GoodsFactory;
import com.tema1.goods.GoodsType;

import java.util.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import static java.util.stream.Collectors.*;


public class Player {
    private String strategy;
    private Map<Integer, Integer> playerCards = new HashMap<>();
    private boolean isSheriff;

    public Player() {
        strategy = null;
//        playerCards = null;
        isSheriff = false;
    }

    public Player(String strategy, Map<Integer, Integer> playerCards) {
        this.strategy = strategy;
        this.playerCards = playerCards;
        isSheriff = false;
    }

    public Player(String strategy) {
        this.strategy = strategy;
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }

    public boolean isSheriff() {
        return isSheriff;
    }

    public final boolean getSheriff() {
        return this.isSheriff;
    }


    public void setSheriff(boolean sheriff) {
        isSheriff = sheriff;
    }

    public Map<Integer, Integer> getPlayerCards() {
        return playerCards;
    }

    public void setPlayerCards(List<Integer> gameCards) {
        int i = 0;
        for (int card : gameCards) {
            if (i == 10)
                break;
            this.playerCards.put(card, Collections.frequency(gameCards.subList(0, 10), card));

            i++;
        }
        gameCards.subList(0, 10).clear();
        this.playerCards = mostFrequent();
        System.out.println(isAllIllegals());
    }

    public boolean isAllIllegals() {
        int i = 0;
        for(Map.Entry<Integer, Integer> val : playerCards.entrySet()) {
            if (GoodsFactory.getInstance().getGoodsById(val.getKey()).getType().equals(GoodsType.Illegal))
                i++;
        }
        return i == playerCards.size();
    }

    public Map<Integer, Integer> mostFrequent(){
        int max_count = 0;
        Map<Integer, Integer> res = new HashMap<>();
        Map<Integer, Integer> sortedByFrequency = playerCards
                .entrySet()
                .stream()
                .sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
                .collect(
                        toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2,
                                LinkedHashMap::new));

        for(Map.Entry<Integer, Integer> val : sortedByFrequency.entrySet())
        {
            if (max_count <= val.getValue())
            {
                res.put(val.getKey(), val.getValue());
                max_count = val.getValue();
            }
        }

        return res;
    }

    public int bagSize(){
        return playerCards.size() - 2;
    }

    public void basicSetBag() {

    }

    public void setBag() {

        if (strategy.equals("basic")) {


        }
        if (strategy.equals("greedy")) {

        }
        if (strategy.equals("bribed")) {

        }

    }



    @Override
    public String toString() {
        String cards = playerCards.toString();

        return "" + strategy + "\t:" + cards ;

    }
}
